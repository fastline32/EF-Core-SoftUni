﻿namespace CarDealer.DTO
{
    public class SupplierInsertModel
    {
        public string Name { get; set; }
        public bool IsImporter { get; set; }
    }
}