﻿namespace BookShop.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-GURIVTB\SQLEXPRESS;Database=BookShopExam;Trusted_Connection=True";
    }
}